import dash
from dash import dcc, html
from dash.dependencies import Input, Output, State
import plotly.graph_objects as go
import yfinance as yf
from sklearn.preprocessing import MinMaxScaler
import numpy as np
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, LSTM, Dropout
import os


def fetch_bitcoin_data():
    df = yf.download(tickers='BTC-USD', period='1y', interval='1h')
    return df

# Define a function to preprocess data
def preprocess_data(df):
    data = df['Close'].values
    data = data.reshape(-1, 1)
    scaler = MinMaxScaler(feature_range=(0, 1))
    scaled_data = scaler.fit_transform(data)
    lookback = 60
    x, y = [], []
    for i in range(lookback, len(scaled_data)):
        x.append(scaled_data[i-lookback:i, 0])
        y.append(scaled_data[i, 0])
    x, y = np.array(x), np.array(y)
    x = np.reshape(x, (x.shape[0], x.shape[1], 1))
    return x, y, scaler

# Initialize the LSTM model
model = Sequential()
model.add(LSTM(units=256, activation='relu', return_sequences=True, input_shape=(60, 1)))
model.add(LSTM(units=256, activation='relu', return_sequences=True))
model.add(LSTM(units=256, activation='relu'))
model.add(Dense(units=1))


app = dash.Dash(__name__)

# Define the layout of app
app.layout = html.Div(children=[
    html.H1(children="Real-time Bitcoin Price Vs Prediction"),
    dcc.Graph(id='live-graph', animate=True),
    dcc.Interval(
        id='interval-component',
        interval=1*3600000, # in milliseconds (1 hour)
        n_intervals=0
    )
])

# Define the callback for updating  graph
@app.callback(Output('live-graph', 'figure'),
              [Input('interval-component', 'n_intervals')])
def update_graph_live(n):
    data = fetch_bitcoin_data()
    x, y, scaler = preprocess_data(data)

    # Compile and fit the LSTM model
    model.compile(optimizer='adam', loss='mean_squared_error')

    print("Training the model")
    model.fit(x, y, epochs=1, batch_size=1, verbose=0)
    print("Model trained")

    prediction = model.predict(x)
    prediction = scaler.inverse_transform(prediction)
    graph = go.Figure(
        data=[
            go.Scatter(
                x=data.index[-len(prediction):],
                y=data['Close'].iloc[-len(prediction):],
                mode='lines',
                name='Actual Price'
            ),
            go.Scatter(
                x=data.index[-len(prediction):],
                y=prediction.flatten(),
                mode='lines',
                name='Predicted Price'
            )
        ]
    )
    return graph

if __name__ == '__main__':
    app.run_server(host='0.0.0.0', port=int(os.environ.get('PORT', 8052)))
