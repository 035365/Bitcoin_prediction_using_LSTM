import requests
import dash
from dash import dcc, html
from dash.dependencies import Input, Output
import plotly.graph_objects as go
import yfinance as yf
from sklearn.preprocessing import MinMaxScaler
import numpy as np
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, LSTM, Dropout, Concatenate
from tensorflow.keras.optimizers import Adam
import pandas as pd
import datetime
import os

def fetch_live_price():
    url = 'https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=usd'
    response = requests.get(url)
    if response.status_code == 200:
        data = response.json()
        btc_price = data['bitcoin']['usd']
        return btc_price
    else:
        return None

# Fetch data
end_date = datetime.datetime.now().replace(minute=0, second=0, microsecond=0)
start_date = end_date - datetime.timedelta(days=365)
data = yf.download('BTC-USD', start=start_date, end=end_date, interval='1h')

# Preprocess data
scaler = MinMaxScaler(feature_range=(0, 1))
data['Close'] = scaler.fit_transform(data['Close'].values.reshape(-1, 1))
data['High'] = scaler.transform(data['High'].values.reshape(-1, 1))
data['Low'] = scaler.transform(data['Low'].values.reshape(-1, 1))

# Convert data into input sequences
def create_sequences(data, n_steps):
    X, y = [], []
    for i in range(len(data) - n_steps - 1):
        X.append(data[i:i+n_steps])
        y.append(data[i+n_steps])
    return np.array(X), np.array(y)

n_steps = 72  # Define the number of time steps

X_train, y_train = create_sequences(data[['Close', 'High', 'Low']].values, n_steps)

# Reshape input for LSTM model
X_train = np.reshape(X_train, (X_train.shape[0], X_train.shape[1], 3))

# Build the LSTM model
model = Sequential()
model.add(LSTM(256, activation='relu', input_shape=(n_steps, 3), return_sequences=True))
model.add(LSTM(256, activation='relu', return_sequences=True))
model.add(LSTM(256, activation='relu'))
model.add(Dense(1))
model.compile(optimizer=Adam(learning_rate=0.0001), loss='mean_squared_error')

# Train the LSTM model with adjusted factors
epochs = 10
batch_size = 64

model.fit(X_train, y_train, epochs=epochs, batch_size=batch_size)

# Dash app
app = dash.Dash(__name__)

app.layout = html.Div([
    html.H1(children="Bitcoin live price"),
    html.A(html.Button('Comparison', id='comparison-button', style={'background-color': '#4CAF50', 'color': 'white', 'padding': '10px 20px', 'border': 'none', 'border-radius': '4px', 'cursor': 'pointer', 'font-size': '16px'}),
           href='http://172.20.10.2:8052/', target='_blank'),#replace the url with the url tht given by terminal server on the time of runing
    html.A(html.Button('Buy/Sell BTC', id='buy-sell-button', style={'background-color': '#4CAF50', 'color': 'white', 'padding': '10px 20px', 'border': 'none', 'border-radius': '4px', 'cursor': 'pointer', 'font-size': '16px'}),
           href='https://bitcoin.org/en/buy', target='_blank'),
    html.Div([]),
    html.Div([
        dcc.Graph(id='live-graph'),
        dcc.Graph(id='btc-predictions'),
    ]),
    dcc.Interval(
        id='interval-component',
        interval=5 * 1000,  # 5 seconds
        n_intervals=0
    )
])

@app.callback(Output('live-graph', 'figure'),
              [Input('interval-component', 'n_intervals')])
def update_graph_live(n):
    graph = go.Figure()

    # Fetch live BTC price
    btc_price = fetch_live_price()
    if btc_price:
        current_time = datetime.datetime.now()
        graph.add_trace(go.Scatter(x=[current_time], y=[btc_price], mode='markers', name='Live Price'))

    graph.update_layout(title='Bitcoin Price', xaxis_title='Date', yaxis_title='Price')
    return graph


@app.callback(Output('btc-predictions', 'figure'),
              [Input('interval-component', 'n_intervals')])
def update_predictions(n):
    # Update the LSTM model with new data
    data = yf.download('BTC-USD', start=start_date, end=datetime.datetime.now(), interval='1h')
    data['Close'] = scaler.transform(data['Close'].values.reshape(-1, 1))
    data['High'] = scaler.transform(data['High'].values.reshape(-1, 1))
    data['Low'] = scaler.transform(data['Low'].values.reshape(-1, 1))
    X_sequence = np.array(data[['Close', 'High', 'Low']][-n_steps:]).reshape(1, n_steps, 3)
    prediction_data = []

    # Define the number of intervals for 24 hours (24 intervals per day)
    prediction_intervals = 24

    # Generate predictions for 24 hours
    for _ in range(prediction_intervals):
        prediction = model.predict(X_sequence)[0][0]
        prediction_data.append(prediction)
        X_sequence = np.roll(X_sequence, -1)
        X_sequence[0, -1] = [prediction, prediction, prediction]  # Set the last input sequence to the prediction values

    # Rescale the predictions
    prediction_data = scaler.inverse_transform(np.array(prediction_data).reshape(-1, 1))

    # Create future timestamps for 24 hours
    future_timestamps = pd.date_range(end_date, periods=prediction_intervals, freq='H')

    graph = go.Figure()
    graph.add_trace(go.Scatter(x=future_timestamps[:prediction_intervals], y=prediction_data.flatten()[:prediction_intervals], name='Future Predictions'))
    graph.update_layout(title='BTC Price Predictions for the Next 24 Hours',
                       xaxis_title='Date', yaxis_title='Price')
    return graph

if __name__ == '__main__':
    app.run_server(host='0.0.0.0', port=int(os.environ.get('PORT', 8051)))
